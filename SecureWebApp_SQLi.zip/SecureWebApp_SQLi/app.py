from flask import (
    Flask, render_template, request,
    redirect, session, flash, url_for, abort
)
import sqlite3
import os
import re
from datetime import timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.permanent_session_lifetime = timedelta(minutes=30)

# ---------- DATABASE SETUP ----------
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# ---------- INPUT SANITIZATION ----------
def is_input_safe(text):
    """
    Returns False if the input contains SQL metacharacters
    that could lead to SQL injection.
    This pattern looks for single‑quotes, comment marks, semicolons, /* or */ 
    """
    return not re.search(r"('|--|;|/\*|\*/)", text)

# ---------- LOG ATTEMPTS ----------
def log_attempt(username, password):
    """
    Appends every login attempt to injection_attempts.log.
    """
    if not os.path.exists('injection_attempts.log'):
        open('injection_attempts.log', 'w').close()
    with open('injection_attempts.log', 'a') as f:
        f.write(f"Attempted login: username='{username}' password='{password}'\n")

# ---------- ROUTES ----------
@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

               # Log every login attempt
        log_attempt(username, password)

        # OPTIONAL: You can temporarily disable this sanitization during SQLi demo
        # if not is_input_safe(username) or not is_input_safe(password):
        #     flash("Invalid characters detected in input!")
        #     return redirect(url_for('login'))

        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()

        # ⚠️ VULNERABLE SQL QUERY (ONLY FOR DEMO – DO NOT USE IN REAL APP)
        # Uncomment the following lines to demonstrate SQL Injection
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        cursor.execute(query)
        user = cursor.fetchone()

        # ✅ SECURE SQL QUERY (recommended for real usage)
         #cursor.execute(
           # 'SELECT * FROM users WHERE username = ? AND password = ?',
            # (username, password)
         #)
         #user = cursor.fetchone()

        conn.close()

        if user:
            session.permanent = True
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials!")
            return redirect(url_for('login'))

    return render_template('auth.html', username=None)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('users.db')
        c = conn.cursor()

        # Check if username exists
        c.execute('SELECT * FROM users WHERE username = ?', (username,))
        if c.fetchone():
            flash("Username already exists. Try another.")
            conn.close()
            return redirect(url_for('register'))

        # Insert new user securely
        c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        flash("Registration successful! You can now log in.")
        return redirect(url_for('login'))

    return render_template('auth.html', register=True)

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('auth.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("You have been logged out.")
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if session.get('username') != 'admin':
        abort(403)
    if not os.path.exists('injection_attempts.log'):
        logs = ["No attempts logged yet."]
    else:
        with open('injection_attempts.log', 'r') as f:
            logs = f.readlines()
    return render_template('report.html', logs=logs)

# ---------- RUN SERVER ----------
if __name__ == '__main__':
    init_db()
    print("🔥 Flask app starting on http://127.0.0.1:5000 …")
    app.run(debug=True)
